Replicated-Concurrency-Control-and-Recovery-in-Distributed-Database-System
==========================================================================
1. Project Summary:
    This is the implementation of a distributed database, complete with multiversion concurrency control, deadlock avoidance, replication, and failure recovery.
We assume that our database cannot be corrupted and will be used for the baseline scenario. Therefore it does not need to be set up because it's
already running. 

2. Replication Type: Active replication


3. Members:
    Sai Deepika Gopala, Tejaswi Eerpina

4. Environments setting in .bashrc file :
	
	export JAVA_BINDIR=/afs/ece/usr/deepika/java5/jdk1.5.0_06/bin
	export JAVA_HOME=/afs/ece/usr/deepika/java5/jdk1.5.0_06
	export JAVA_ROOT=/afs/ece/usr/deepika/java5/jdk1.5.0_06/jre
	export JRE_HOME=/afs/ece/usr/deepika/java5/jdk1.5.0_06/jre
	export PATH=/afs/ece/usr/deepika/java5/jre1.5.0_06/bin:/afs/ece/usr/deepika/java5/jdk1.5.0_06/bin:$PATH
	export PATH=$PATH:/usr/local/mysql/bin
	export CLASSPATH_ROOT=$HOME/lib
	export CLASSPATH=.:$CLASSPATH_ROOT/commons-collections-3.1.jar:$CLASSPATH_ROOT/commons-dbcp-1.2.jar:$CLASSPATH_ROOT/commons-pool-1.2.jar:$CLASSPATH_ROOT/mysql-connector-java-3.1.12-bin.jar:$CLASSPATH_ROOT/log4j-1.2.9.jar:$HOME/config:$HOME/src/FaultSixers


 
5. Run programs 
Import the project into eclipse IDE and run the Test.jave file as Java Program.


6. Algorithms used:

- Two-phase locking
- Two-phase commit
- Wait-die to avoid deadlocks
- Available copies
- Multi-version read consistency
